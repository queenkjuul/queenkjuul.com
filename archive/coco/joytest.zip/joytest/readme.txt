program for calibrating tandy deluxe joysticks
you can adjust the calibration wheels on the joystick so that you get a stable center
values of 0,0 indicate dead center, but if you manage to get -1/1, quit while you're ahead :)

Queen K Juul, August 2021

Live long and prosper, loves